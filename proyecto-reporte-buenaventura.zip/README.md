# ReporteBuenaventura

Sistema de reportes ciudadanos para Buenaventura, Colombia. Plataforma web que permite a los ciudadanos reportar problemas urbanos y dar seguimiento a su resolución.

## Características

- **Autenticación de usuarios** con Supabase Auth
- **Clasificación automática con IA** de reportes
- **Panel administrativo** completo para gestión
- **Seguimiento en tiempo real** de reportes
- **Sistema de comentarios** y calificaciones
- **Gestión de entidades** gubernamentales
- **Mapas interactivos** para ubicación de reportes
- **Compartir en redes sociales**

## Tecnologías

- **Next.js 15** - Framework React
- **Supabase** - Base de datos y autenticación
- **TypeScript** - Tipado estático
- **Tailwind CSS** - Estilos
- **shadcn/ui** - Componentes UI
- **Leaflet** - Mapas interactivos

## Requisitos Previos

- Node.js 18+ 
- Cuenta de Supabase
- Cuenta de Vercel (para despliegue)

## Instalación Local

1. Clona el repositorio:
\`\`\`bash
git clone <tu-repositorio>
cd ProyectoReporteBuenaventura
\`\`\`

2. Instala las dependencias:
\`\`\`bash
npm install
\`\`\`

3. Configura las variables de entorno:
Crea un archivo `.env.local` con:
\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=tu_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_supabase_anon_key
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000
\`\`\`

4. Ejecuta los scripts SQL en Supabase:
Ejecuta los archivos en orden desde la carpeta `scripts/`:
- `01-create-tables.sql`
- `02-enable-rls.sql`
- `03-seed-data.sql`
- `04-create-functions.sql`

5. Inicia el servidor de desarrollo:
\`\`\`bash
npm run dev
\`\`\`

Abre [http://localhost:3000](http://localhost:3000) en tu navegador.

## Configuración de Supabase

### 1. Crear Proyecto en Supabase

1. Ve a [supabase.com](https://supabase.com)
2. Crea un nuevo proyecto
3. Guarda la URL y la clave anónima

### 2. Ejecutar Scripts SQL

En el SQL Editor de Supabase, ejecuta los scripts en orden:

1. **01-create-tables.sql** - Crea todas las tablas
2. **02-enable-rls.sql** - Configura seguridad Row Level Security
3. **03-seed-data.sql** - Inserta datos iniciales
4. **04-create-functions.sql** - Crea funciones automáticas

### 3. Configurar Autenticación

En Supabase Dashboard:
1. Ve a Authentication > Providers
2. Habilita Email provider
3. Configura las URLs de redirección

## Despliegue en Vercel

### Opción 1: Desde v0

1. Haz clic en el botón "Publish" en v0
2. Conecta tu cuenta de Vercel
3. Configura las variables de entorno
4. Despliega

### Opción 2: Desde GitHub

1. Sube el código a GitHub
2. Importa el proyecto en Vercel
3. Configura las variables de entorno:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Despliega

## Estructura del Proyecto

\`\`\`
ProyectoReporteBuenaventura/
├── app/                      # App Router de Next.js
│   ├── login/               # Página de login
│   ├── layout.tsx           # Layout principal
│   ├── page.tsx             # Página principal
│   └── globals.css          # Estilos globales
├── components/              # Componentes React
│   ├── ui/                  # Componentes UI de shadcn
│   └── main-app.tsx         # Componente principal
├── lib/                     # Utilidades y configuración
│   ├── actions/             # Server Actions
│   │   ├── auth.ts         # Acciones de autenticación
│   │   ├── reports.ts      # Acciones de reportes
│   │   ├── entities.ts     # Acciones de entidades
│   │   ├── comments.ts     # Acciones de comentarios
│   │   └── users.ts        # Acciones de usuarios
│   ├── supabase/           # Clientes de Supabase
│   │   ├── client.ts       # Cliente del navegador
│   │   └── server.ts       # Cliente del servidor
│   └── utils.ts            # Utilidades generales
├── scripts/                # Scripts SQL para Supabase
│   ├── 01-create-tables.sql
│   ├── 02-enable-rls.sql
│   ├── 03-seed-data.sql
│   └── 04-create-functions.sql
├── middleware.ts           # Middleware de autenticación
└── package.json           # Dependencias

\`\`\`

## Usuarios de Prueba

### Administrador
- Email: `admin@buenaventura.gov.co`
- Contraseña: Configurar en Supabase Auth

### Ciudadano
- Registrarse desde la aplicación

## Funcionalidades Principales

### Para Ciudadanos
- Crear reportes con ubicación en mapa
- Adjuntar fotos
- Clasificación automática con IA
- Seguimiento de reportes propios
- Comentar en reportes
- Calificar resolución de reportes
- Compartir en redes sociales

### Para Administradores
- Dashboard con analytics
- Gestión de todos los reportes
- Cambiar estado de reportes
- Reasignar entidades
- Gestión de usuarios
- Gestión de entidades gubernamentales
- Ver historial de cambios

## Seguridad

- Row Level Security (RLS) habilitado en todas las tablas
- Autenticación con Supabase Auth
- Middleware para proteger rutas
- Validación de permisos en server actions

## Soporte

Para soporte técnico, contacta:
- Email: johnvalenciazp@gmail.com
- Email: jhon.william.angulo@correounivalle.edu.co
- WhatsApp: +57 3106507940
- Teléfono: +57 3106507940

## Licencia

© 2025 ZPservicioTecnico. Todos los derechos reservados.

Desarrollado con ❤️ para Buenaventura
