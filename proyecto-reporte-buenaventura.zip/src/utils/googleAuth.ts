// Simulación de Google OAuth
// En producción, usar Google OAuth 2.0 real

interface GoogleUser {
  id: string;
  email: string;
  name: string;
  picture?: string;
}

export async function signInWithGoogle(): Promise<GoogleUser> {
  // Simular el flujo de Google OAuth
  return new Promise((resolve, reject) => {
    // En producción, abrir ventana de OAuth de Google
    // window.open('https://accounts.google.com/o/oauth2/v2/auth?...')
    
    // Simulación: mostrar prompt
    const confirmed = window.confirm(
      '¿Deseas iniciar sesión con Google?\n\n' +
      'Nota: Esta es una simulación. En producción, se abrirá la ventana de Google OAuth.'
    );

    if (confirmed) {
      // Simular respuesta de Google
      setTimeout(() => {
        const mockUser: GoogleUser = {
          id: 'google-' + Date.now(),
          email: 'usuario@gmail.com',
          name: 'Usuario Google',
          picture: undefined
        };
        resolve(mockUser);
      }, 1000);
    } else {
      reject(new Error('Login cancelado'));
    }
  });
}

// Función para configurar Google OAuth real
export function initGoogleAuth(clientId: string) {
  // En producción:
  // 1. Agregar el script de Google Identity Services
  // 2. Inicializar con el clientId
  // 3. Configurar el callback
  // Google Auth initialized successfully
}
