import { useState } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { MapPin, Mail, Lock, User, Loader2, Eye, EyeOff, CheckCircle, Phone } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { signInWithGoogle } from '../utils/googleAuth';
import { sendPasswordResetEmail, generateResetToken, createPasswordResetLink, storeResetToken } from '../utils/emailService';

interface LoginPageProps {
  onLogin: (user: { id: string; email: string; name: string; role: 'admin' | 'ciudadano' }) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [registerName, setRegisterName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotPasswordMessage, setForgotPasswordMessage] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      // Check for admin credentials
      if (loginEmail === 'admin@buenaventura.gov.co' && loginPassword === 'admin123') {
        onLogin({
          id: 'admin-1',
          email: loginEmail,
          name: 'Administrador',
          role: 'admin'
        });
        return;
      }

      // Check stored users
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const user = users.find((u: any) => u.email === loginEmail && u.password === loginPassword);

      if (user) {
        onLogin({
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role
        });
      } else {
        setError('Email o contraseña incorrectos');
        setLoading(false);
      }
    }, 500);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      if (!registerName || !registerEmail || !registerPassword) {
        setError('Por favor completa todos los campos');
        setLoading(false);
        return;
      }

      // Check if user already exists
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const existingUser = users.find((u: any) => u.email === registerEmail);

      if (existingUser) {
        setError('Ya existe un usuario con este email');
        setLoading(false);
        return;
      }

      // Create new user
      const newUser = {
        id: Date.now().toString(),
        email: registerEmail,
        name: registerName,
        password: registerPassword,
        role: 'ciudadano' as const,
        createdAt: new Date().toISOString()
      };

      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));

      // Auto login
      onLogin({
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        role: newUser.role
      });
    }, 500);
  };

  const handleForgotPassword = async () => {
    setForgotPasswordMessage('');
    setLoading(true);
    
    if (!forgotEmail) {
      setForgotPasswordMessage('Por favor ingresa tu correo electrónico');
      setLoading(false);
      return;
    }

    // Check if user exists
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find((u: any) => u.email === forgotEmail);

    if (!user && forgotEmail !== 'admin@buenaventura.gov.co') {
      setForgotPasswordMessage('Usuario no registrado. ¿Deseas registrarte?');
      setLoading(false);
      return;
    }

    // Generate reset token and create reset link
    const resetToken = generateResetToken();
    const resetLink = createPasswordResetLink(forgotEmail, resetToken);
    
    // Store token (in production, this would be in backend database)
    storeResetToken(forgotEmail, resetToken);

    // Send password reset email
    const userName = user ? user.name : 'Administrador';
    const emailSent = await sendPasswordResetEmail({
      toEmail: forgotEmail,
      userName,
      resetLink
    });

    if (emailSent) {
      setForgotPasswordMessage('✅ Se ha enviado un enlace de recuperación a tu correo electrónico. Por favor revisa tu bandeja de entrada.');
    } else {
      setForgotPasswordMessage('❌ Hubo un error al enviar el correo. Por favor intenta de nuevo.');
    }
    
    setLoading(false);
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    
    try {
      const googleUser = await signInWithGoogle();
      
      // Check if user exists
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      let user = users.find((u: any) => u.email === googleUser.email);
      
      if (!user) {
        // Create new user from Google
        user = {
          id: googleUser.id,
          email: googleUser.email,
          name: googleUser.name,
          role: 'ciudadano' as const,
          googleAuth: true,
          createdAt: new Date().toISOString()
        };
        users.push(user);
        localStorage.setItem('users', JSON.stringify(users));
      }
      
      onLogin({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role
      });
    } catch (error) {
      setError('No se pudo iniciar sesión con Google');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-400 via-yellow-400 to-lime-500 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl bg-gradient-to-r from-white via-yellow-100 to-white bg-clip-text text-transparent drop-shadow-lg mb-3">
            Reporte de Buenaventura
          </h1>
          <p className="text-white/95 text-base md:text-lg drop-shadow-md">
            Una plataforma de reportes ciudadanos
          </p>
        </div>

        {/* Main Card */}
        <Card className="shadow-2xl border-4 border-white/50 backdrop-blur-sm bg-white/95">
          <CardContent className="p-8">
            {/* Tab-like header */}
            <div className="mb-6 text-center">
              <h2 className="text-2xl text-green-800 mb-2">
                {isLogin ? 'Iniciar Sesión' : 'Registrar Cuenta'}
              </h2>
              <p className="text-sm text-gray-600">
                {isLogin 
                  ? 'Ingresa a tu cuenta para reportar' 
                  : 'Regístrate para empezar a reportar'}
              </p>
            </div>

            {isLogin ? (
              /* Login Form */
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-green-800">Correo</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                    <Input
                      type="email"
                      placeholder="nombre@ejemplo.com"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      className="pl-9 h-12 border-2 border-green-200 focus:border-green-400 rounded-xl"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-green-800">Contraseña</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                    <Input
                      type={showLoginPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="pl-9 pr-11 h-12 border-2 border-green-200 focus:border-green-400 rounded-xl"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPassword(!showLoginPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {error && (
                  <Alert variant="destructive" className="rounded-xl">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button 
                  type="submit" 
                  className="w-full h-12 bg-gradient-to-r from-green-500 to-yellow-400 hover:from-green-600 hover:to-yellow-500 text-white rounded-xl shadow-lg" 
                  size="lg"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Iniciando...
                    </>
                  ) : (
                    'Iniciar Sesión'
                  )}
                </Button>

                <div className="text-center pt-3 pb-2">
                  <button
                    type="button"
                    className="text-sm text-green-600 hover:text-green-700 hover:underline transition-colors"
                    onClick={() => {
                      setShowForgotPassword(true);
                      setForgotEmail('');
                      setForgotPasswordMessage('');
                    }}
                  >
                    ¿Has olvidado la contraseña?
                  </button>
                </div>
              </form>
            ) : (
              /* Register Form */
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-green-800">Nombre Completo</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                    <Input
                      type="text"
                      placeholder="Juan Pérez"
                      value={registerName}
                      onChange={(e) => setRegisterName(e.target.value)}
                      className="pl-9 h-12 border-2 border-green-200 focus:border-green-400 rounded-xl"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-green-800">Correo</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                    <Input
                      type="email"
                      placeholder="nombre@ejemplo.com"
                      value={registerEmail}
                      onChange={(e) => setRegisterEmail(e.target.value)}
                      className="pl-9 h-12 border-2 border-green-200 focus:border-green-400 rounded-xl"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-green-800">Contraseña</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                    <Input
                      type={showRegisterPassword ? "text" : "password"}
                      placeholder="Mínimo 6 caracteres"
                      value={registerPassword}
                      onChange={(e) => setRegisterPassword(e.target.value)}
                      className="pl-9 pr-11 h-12 border-2 border-green-200 focus:border-green-400 rounded-xl"
                      required
                      minLength={6}
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegisterPassword(!showRegisterPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      {showRegisterPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {error && (
                  <Alert variant="destructive" className="rounded-xl">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button 
                  type="submit" 
                  className="w-full h-12 bg-gradient-to-r from-green-500 to-yellow-400 hover:from-green-600 hover:to-yellow-500 text-white rounded-xl shadow-lg" 
                  size="lg"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Registrando...
                    </>
                  ) : (
                    'Registrar'
                  )}
                </Button>
              </form>
            )}

            {/* Divider */}
            <div className="my-8">
              <Separator className="bg-gray-200" />
            </div>

            {/* Google Button */}
            <Button
              type="button"
              variant="outline"
              className="w-full h-12 border-2 border-gray-200 hover:bg-gray-50 rounded-xl"
              onClick={handleGoogleLogin}
              disabled={loading}
            >
              <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              {loading ? 'Conectando...' : 'Continuar con Google'}
            </Button>

            {/* Toggle Login/Register */}
            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600 mb-3">
                {isLogin ? '¿Eres nuevo?' : '¿Ya tienes cuenta?'}{' '}
              </p>
              <Button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setError('');
                }}
                className="w-full h-12 bg-gradient-to-r from-green-500 to-yellow-400 hover:from-green-600 hover:to-yellow-500 text-white rounded-xl shadow-lg"
              >
                {isLogin ? 'Registrar' : 'Iniciar Sesión'}
              </Button>
            </div>

            {/* Admin Info */}
            {isLogin && (
              <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-yellow-50 rounded-xl border-2 border-green-200">
                <p className="text-xs text-green-900 mb-2">🔑 Cuenta de prueba Admin:</p>
                <div className="space-y-1">
                  <p className="text-xs text-green-700">Email: admin@buenaventura.gov.co</p>
                  <p className="text-xs text-green-700">Contraseña: admin123</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8 space-y-3">
          <p className="text-white/90 text-sm drop-shadow-md">
            © 2025 ZPservicioTecnico
          </p>
          <div className="space-y-2">
            <div className="flex items-center justify-center gap-2">
              <Mail className="w-3 h-3 text-white/80" />
              <a 
                href="mailto:johnvalenciazp@gmail.com" 
                className="text-white/90 text-xs drop-shadow-md hover:text-white transition-colors"
              >
                johnvalenciazp@gmail.com
              </a>
            </div>
            <div className="flex items-center justify-center gap-2">
              <Mail className="w-3 h-3 text-white/80" />
              <a 
                href="mailto:jhon.william.angulo@correounivalle.edu.co" 
                className="text-white/90 text-xs drop-shadow-md hover:text-white transition-colors"
              >
                jhon.william.angulo@correounivalle.edu.co
              </a>
            </div>
            <div className="flex items-center justify-center gap-2">
              <svg className="w-3 h-3 text-white/80" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
              </svg>
              <a 
                href="https://wa.me/573106507940" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/90 text-xs drop-shadow-md hover:text-white transition-colors"
              >
                WhatsApp
              </a>
            </div>
            <div className="flex items-center justify-center gap-2">
              <Phone className="w-3 h-3 text-white/80" />
              <a 
                href="tel:+573106507940" 
                className="text-white/90 text-xs drop-shadow-md hover:text-white transition-colors"
              >
                +57 3106507940
              </a>
            </div>
          </div>
          <p className="text-white/90 text-sm drop-shadow-md pt-2">
            Desarrollado con un ❤️ para Buenaventura
          </p>
        </div>
      </div>

      {/* Forgot Password Dialog */}
      <Dialog open={showForgotPassword} onOpenChange={setShowForgotPassword}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-green-800">Recuperar Contraseña</DialogTitle>
            <DialogDescription>
              Ingresa tu correo electrónico para recibir un enlace de recuperación
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm text-green-800">Correo Electrónico</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                <Input
                  type="email"
                  placeholder="nombre@ejemplo.com"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  className="pl-9 h-12 border-2 border-green-200 focus:border-green-400 rounded-xl"
                />
              </div>
            </div>

            {forgotPasswordMessage && (
              <Alert className={
                forgotPasswordMessage.includes('no registrado') 
                  ? "border-yellow-500 bg-yellow-50" 
                  : forgotPasswordMessage.includes('✅')
                  ? "border-green-500 bg-green-50"
                  : "border-red-500 bg-red-50"
              }>
                <AlertDescription className="text-sm">{forgotPasswordMessage}</AlertDescription>
              </Alert>
            )}

            <div className="flex flex-col gap-2">
              <Button
                onClick={handleForgotPassword}
                disabled={loading}
                className="w-full h-12 bg-gradient-to-r from-green-500 to-yellow-400 hover:from-green-600 hover:to-yellow-500 text-white rounded-xl"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  'Enviar Enlace'
                )}
              </Button>

              {forgotPasswordMessage.includes('no registrado') && (
                <Button
                  onClick={() => {
                    setShowForgotPassword(false);
                    setIsLogin(false);
                    setRegisterEmail(forgotEmail);
                  }}
                  variant="outline"
                  className="w-full h-12 border-2 border-green-200 hover:bg-green-50 text-green-700 rounded-xl"
                >
                  Registrar Usuario
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
