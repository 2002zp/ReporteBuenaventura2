# Guía de Despliegue - ReporteBuenaventura

Esta guía te ayudará a desplegar la aplicación en producción.

## Paso 1: Configurar Supabase

### 1.1 Crear Proyecto
1. Ve a [supabase.com](https://supabase.com)
2. Crea un nuevo proyecto
3. Espera a que se complete la configuración
4. Guarda la URL del proyecto y la clave anónima

### 1.2 Ejecutar Scripts SQL
En el SQL Editor de Supabase, ejecuta los scripts en este orden:

\`\`\`sql
-- 1. Crear tablas
-- Ejecuta: scripts/01-create-tables.sql

-- 2. Habilitar seguridad
-- Ejecuta: scripts/02-enable-rls.sql

-- 3. Insertar datos iniciales
-- Ejecuta: scripts/03-seed-data.sql

-- 4. Crear funciones
-- Ejecuta: scripts/04-create-functions.sql
\`\`\`

### 1.3 Configurar Autenticación

1. Ve a **Authentication > Providers**
2. Habilita **Email** provider
3. En **Authentication > URL Configuration**, agrega:
   - Site URL: `https://tu-dominio.vercel.app`
   - Redirect URLs: `https://tu-dominio.vercel.app/**`

### 1.4 Crear Usuario Administrador

1. Ve a **Authentication > Users**
2. Crea un nuevo usuario con:
   - Email: `admin@buenaventura.gov.co`
   - Contraseña: (elige una segura)
3. En la tabla `users`, actualiza el rol a `admin`:
\`\`\`sql
UPDATE users 
SET role = 'admin' 
WHERE email = 'admin@buenaventura.gov.co';
\`\`\`

## Paso 2: Desplegar en Vercel

### Opción A: Desde v0 (Recomendado)

1. En v0, haz clic en el botón **"Publish"**
2. Conecta tu cuenta de Vercel
3. Configura las variables de entorno:
   - `NEXT_PUBLIC_SUPABASE_URL`: Tu URL de Supabase
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Tu clave anónima de Supabase
4. Haz clic en **"Deploy"**
5. Espera a que se complete el despliegue

### Opción B: Desde GitHub

1. **Subir código a GitHub:**
\`\`\`bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/tu-usuario/reporte-buenaventura.git
git push -u origin main
\`\`\`

2. **Importar en Vercel:**
   - Ve a [vercel.com](https://vercel.com)
   - Haz clic en "New Project"
   - Importa tu repositorio de GitHub
   - Configura las variables de entorno
   - Despliega

### Opción C: Vercel CLI

\`\`\`bash
# Instalar Vercel CLI
npm i -g vercel

# Login
vercel login

# Desplegar
vercel

# Configurar variables de entorno
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY

# Desplegar a producción
vercel --prod
\`\`\`

## Paso 3: Configuración Post-Despliegue

### 3.1 Actualizar URLs en Supabase

1. Ve a **Authentication > URL Configuration** en Supabase
2. Actualiza:
   - Site URL: `https://tu-dominio.vercel.app`
   - Redirect URLs: `https://tu-dominio.vercel.app/**`

### 3.2 Verificar Variables de Entorno

En Vercel Dashboard:
1. Ve a tu proyecto
2. Settings > Environment Variables
3. Verifica que estén configuradas:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### 3.3 Probar la Aplicación

1. Visita tu URL de producción
2. Intenta registrar un usuario
3. Inicia sesión con el admin
4. Crea un reporte de prueba
5. Verifica todas las funcionalidades

## Paso 4: Configuración de Dominio Personalizado (Opcional)

### En Vercel:
1. Ve a Settings > Domains
2. Agrega tu dominio personalizado
3. Configura los DNS según las instrucciones

### En Supabase:
1. Actualiza las URLs de autenticación con tu nuevo dominio

## Paso 5: Monitoreo y Mantenimiento

### Logs
- **Vercel**: Dashboard > Deployments > Logs
- **Supabase**: Dashboard > Logs

### Analytics
- Vercel Analytics está habilitado automáticamente
- Revisa métricas en Vercel Dashboard

### Backups
- Supabase hace backups automáticos
- Configura backups adicionales en Settings > Database

## Solución de Problemas

### Error: "Invalid API key"
- Verifica que las variables de entorno estén correctas
- Regenera las claves en Supabase si es necesario

### Error: "Authentication failed"
- Verifica las URLs de redirección en Supabase
- Asegúrate de que el dominio esté correcto

### Error: "Database connection failed"
- Verifica que los scripts SQL se ejecutaron correctamente
- Revisa los logs de Supabase

### Reportes no se crean
- Verifica las políticas RLS en Supabase
- Revisa los logs del servidor en Vercel

## Checklist de Despliegue

- [ ] Proyecto de Supabase creado
- [ ] Scripts SQL ejecutados
- [ ] Usuario admin creado
- [ ] Variables de entorno configuradas
- [ ] Aplicación desplegada en Vercel
- [ ] URLs de autenticación actualizadas
- [ ] Dominio personalizado configurado (opcional)
- [ ] Pruebas de funcionalidad completadas
- [ ] Monitoreo configurado

## Contacto de Soporte

Si necesitas ayuda con el despliegue:
- Email: johnvalenciazp@gmail.com
- Email: jhon.william.angulo@correounivalle.edu.co
- WhatsApp: +57 3106507940
