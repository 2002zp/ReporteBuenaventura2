"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail, Lock, User, Loader2, Eye, EyeOff } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true)
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()
  const supabase = createClient()

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
  })

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      })

      if (error) throw error

      toast.success("Inicio de sesión exitoso")
      router.push("/")
      router.refresh()
    } catch (error: any) {
      setError(error.message || "Error al iniciar sesión")
      toast.error("Error al iniciar sesión")
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      // Sign up with Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || window.location.origin,
          data: {
            name: formData.name,
          },
        },
      })

      if (authError) throw authError

      // Insert user into users table
      if (authData.user) {
        const { error: insertError } = await supabase.from("users").insert({
          id: authData.user.id,
          email: formData.email,
          name: formData.name,
          role: "ciudadano",
        })

        if (insertError) throw insertError
      }

      toast.success("Registro exitoso! Revisa tu email para confirmar tu cuenta.")
      setIsLogin(true)
    } catch (error: any) {
      setError(error.message || "Error al registrar")
      toast.error("Error al registrar")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-400 via-yellow-400 to-lime-500 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl bg-gradient-to-r from-white via-yellow-100 to-white bg-clip-text text-transparent drop-shadow-lg mb-3">
            Reporte de Buenaventura
          </h1>
          <p className="text-white/95 text-base md:text-lg drop-shadow-md">Una plataforma de reportes ciudadanos</p>
        </div>

        <Card className="shadow-2xl border-4 border-white/50 backdrop-blur-sm bg-white/95">
          <CardContent className="p-8">
            <div className="mb-6 text-center">
              <h2 className="text-2xl text-green-800 mb-2">{isLogin ? "Iniciar Sesión" : "Registrar Cuenta"}</h2>
              <p className="text-sm text-gray-600">
                {isLogin ? "Ingresa a tu cuenta para reportar" : "Regístrate para empezar a reportar"}
              </p>
            </div>

            <form onSubmit={isLogin ? handleLogin : handleRegister} className="space-y-4">
              {!isLogin && (
                <div className="space-y-2">
                  <label className="text-sm text-green-800">Nombre Completo</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                    <Input
                      type="text"
                      placeholder="Juan Pérez"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="pl-9 h-12 border-2 border-green-200 focus:border-green-400 rounded-xl"
                      required
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-sm text-green-800">Correo</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                  <Input
                    type="email"
                    placeholder="nombre@ejemplo.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="pl-9 h-12 border-2 border-green-200 focus:border-green-400 rounded-xl"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-green-800">Contraseña</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder={isLogin ? "••••••••" : "Mínimo 6 caracteres"}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="pl-9 pr-11 h-12 border-2 border-green-200 focus:border-green-400 rounded-xl"
                    required
                    minLength={6}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <Alert variant="destructive" className="rounded-xl">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                className="w-full h-12 bg-gradient-to-r from-green-500 to-yellow-400 hover:from-green-600 hover:to-yellow-500 text-white rounded-xl shadow-lg"
                size="lg"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    {isLogin ? "Iniciando..." : "Registrando..."}
                  </>
                ) : isLogin ? (
                  "Iniciar Sesión"
                ) : (
                  "Registrar"
                )}
              </Button>
            </form>

            <div className="my-8">
              <Separator className="bg-gray-200" />
            </div>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600 mb-3">{isLogin ? "¿Eres nuevo?" : "¿Ya tienes cuenta?"} </p>
              <Button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin)
                  setError("")
                }}
                className="w-full h-12 bg-gradient-to-r from-green-500 to-yellow-400 hover:from-green-600 hover:to-yellow-500 text-white rounded-xl shadow-lg"
              >
                {isLogin ? "Registrar" : "Iniciar Sesión"}
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-8">
          <p className="text-white/90 text-sm drop-shadow-md">© 2025 ZPservicioTecnico</p>
          <p className="text-white/90 text-sm drop-shadow-md pt-2">Desarrollado con un ❤️ para Buenaventura</p>
        </div>
      </div>
    </div>
  )
}
