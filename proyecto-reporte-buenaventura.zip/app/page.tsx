import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { MainApp } from "@/components/main-app"

export default async function Home() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: userData } = await supabase.from("users").select("*").eq("id", user.id).single()

  if (!userData) {
    redirect("/login")
  }

  return <MainApp user={userData} />
}
