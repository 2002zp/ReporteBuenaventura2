-- Insert default entities
INSERT INTO entities (name, description, category, email, phone, address, website) VALUES
  ('Alcaldía - Infraestructura', 'Encargada de vías, puentes y obras públicas', 'Infraestructura', 'infraestructura@buenaventura.gov.co', '+57 2 243 0000', 'Calle 1 # 1-20, Centro', 'https://www.buenaventura.gov.co'),
  ('Alcaldía - Servicios Públicos', 'Alumbrado público, parques y zonas verdes', 'Servicios', 'servicios@buenaventura.gov.co', '+57 2 243 0001', 'Calle 1 # 1-20, Centro', 'https://www.buenaventura.gov.co'),
  ('Empresa de Aseo', 'Recolección de basuras y aseo público', 'Servicios', 'aseo@buenaventura.gov.co', '+57 2 243 0002', 'Carrera 3 # 2-50', 'https://www.aseobuenaventura.gov.co'),
  ('Empresa de Acueducto', 'Suministro de agua potable y alcantarillado', 'Servicios', 'acueducto@buenaventura.gov.co', '+57 2 243 0003', 'Calle 5 # 3-10', 'https://www.acueductobuenaventura.gov.co'),
  ('Policía', 'Seguridad y orden público', 'Seguridad', 'policia@buenaventura.gov.co', '123', 'Calle 2 # 4-30', 'https://www.policia.gov.co'),
  ('Bomberos', 'Atención de incendios y emergencias', 'Emergencia', 'bomberos@buenaventura.gov.co', '119', 'Carrera 5 # 6-40', 'https://www.bomberos.gov.co'),
  ('Hospital', 'Atención médica y emergencias de salud', 'Salud', 'hospital@buenaventura.gov.co', '125', 'Calle 7 # 8-20', 'https://www.hospitalbuenaventura.gov.co'),
  ('Alcaldía General', 'Para reportes que no corresponden a una entidad específica', 'General', 'contacto@buenaventura.gov.co', '+57 2 243 0000', 'Calle 1 # 1-20, Centro', 'https://www.buenaventura.gov.co')
ON CONFLICT DO NOTHING;

-- Insert demo admin user (password should be set through Supabase Auth)
INSERT INTO users (email, name, role) VALUES
  ('admin@buenaventura.gov.co', 'Administrador', 'admin')
ON CONFLICT (email) DO NOTHING;
