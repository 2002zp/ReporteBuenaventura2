"use server"

import { createClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function getComments(reportId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("comments")
    .select("*")
    .eq("report_id", reportId)
    .order("created_at", { ascending: true })

  if (error) {
    return { error: error.message }
  }

  return { data }
}

export async function createComment(reportId: string, content: string) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return { error: "No autenticado" }
  }

  const { data: userData } = await supabase.from("users").select("*").eq("id", user.id).single()

  if (!userData) {
    return { error: "Usuario no encontrado" }
  }

  const { data, error } = await supabase
    .from("comments")
    .insert({
      report_id: reportId,
      user_id: user.id,
      user_name: userData.name,
      user_role: userData.role,
      content,
    })
    .select()
    .single()

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { data }
}

export async function deleteComment(commentId: string) {
  const supabase = await createClient()

  const { error } = await supabase.from("comments").delete().eq("id", commentId)

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { success: true }
}
