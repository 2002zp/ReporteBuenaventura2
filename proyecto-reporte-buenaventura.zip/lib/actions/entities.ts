"use server"

import { createClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function getEntities() {
  const supabase = await createClient()

  const { data, error } = await supabase.from("entities").select("*").order("name")

  if (error) {
    return { error: error.message }
  }

  return { data }
}

export async function createEntity(formData: FormData) {
  const supabase = await createClient()

  const name = formData.get("name") as string
  const description = formData.get("description") as string
  const category = formData.get("category") as string
  const email = formData.get("email") as string
  const phone = formData.get("phone") as string
  const website = formData.get("website") as string
  const address = formData.get("address") as string

  const { data, error } = await supabase
    .from("entities")
    .insert({
      name,
      description,
      category,
      email: email || null,
      phone: phone || null,
      website: website || null,
      address: address || null,
    })
    .select()
    .single()

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { data }
}

export async function updateEntity(entityId: string, formData: FormData) {
  const supabase = await createClient()

  const name = formData.get("name") as string
  const description = formData.get("description") as string
  const category = formData.get("category") as string
  const email = formData.get("email") as string
  const phone = formData.get("phone") as string
  const website = formData.get("website") as string
  const address = formData.get("address") as string

  const { data, error } = await supabase
    .from("entities")
    .update({
      name,
      description,
      category,
      email: email || null,
      phone: phone || null,
      website: website || null,
      address: address || null,
    })
    .eq("id", entityId)
    .select()
    .single()

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { data }
}

export async function deleteEntity(entityId: string) {
  const supabase = await createClient()

  // Check if entity has reports
  const { data: reports } = await supabase.from("reports").select("id").eq("entity_id", entityId).limit(1)

  if (reports && reports.length > 0) {
    return { error: "No se puede eliminar una entidad con reportes asignados" }
  }

  const { error } = await supabase.from("entities").delete().eq("id", entityId)

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { success: true }
}
