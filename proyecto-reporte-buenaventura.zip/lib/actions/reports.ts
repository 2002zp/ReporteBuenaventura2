"use server"

import { createClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function createReport(formData: FormData) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return { error: "No autenticado" }
  }

  // Get user data
  const { data: userData } = await supabase.from("users").select("*").eq("id", user.id).single()

  if (!userData) {
    return { error: "Usuario no encontrado" }
  }

  const title = formData.get("title") as string
  const description = formData.get("description") as string
  const locationLat = Number.parseFloat(formData.get("location_lat") as string)
  const locationLng = Number.parseFloat(formData.get("location_lng") as string)
  const address = formData.get("address") as string
  const imageUrl = formData.get("image_url") as string
  const entityName = formData.get("entity_name") as string
  const aiClassification = formData.get("ai_classification") as string
  const manuallyAssigned = formData.get("manually_assigned") === "true"

  const { data, error } = await supabase
    .from("reports")
    .insert({
      title,
      description,
      location_lat: locationLat,
      location_lng: locationLng,
      address,
      image_url: imageUrl || null,
      entity_name: entityName,
      user_id: user.id,
      user_name: userData.name,
      user_email: userData.email,
      ai_classification: aiClassification ? JSON.parse(aiClassification) : null,
      manually_assigned: manuallyAssigned,
      status: "pendiente",
    })
    .select()
    .single()

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { data }
}

export async function getReports(userId?: string) {
  const supabase = await createClient()

  let query = supabase.from("reports").select("*").order("created_at", { ascending: false })

  if (userId) {
    query = query.eq("user_id", userId)
  }

  const { data, error } = await query

  if (error) {
    return { error: error.message }
  }

  return { data }
}

export async function updateReportStatus(reportId: string, status: string, notes?: string) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return { error: "No autenticado" }
  }

  const { data, error } = await supabase.from("reports").update({ status }).eq("id", reportId).select().single()

  if (error) {
    return { error: error.message }
  }

  // Create status history entry
  const { data: userData } = await supabase.from("users").select("name").eq("id", user.id).single()

  await supabase.from("report_status_history").insert({
    report_id: reportId,
    new_status: status,
    changed_by: user.id,
    changed_by_name: userData?.name || "Admin",
    notes,
  })

  revalidatePath("/")
  return { data }
}

export async function updateReportEntity(reportId: string, entityName: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("reports")
    .update({ entity_name: entityName })
    .eq("id", reportId)
    .select()
    .single()

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { data }
}

export async function deleteReport(reportId: string) {
  const supabase = await createClient()

  const { error } = await supabase.from("reports").delete().eq("id", reportId)

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { success: true }
}

export async function rateReport(reportId: string, rating: number) {
  const supabase = await createClient()

  const { data, error } = await supabase.from("reports").update({ rating }).eq("id", reportId).select().single()

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { data }
}
