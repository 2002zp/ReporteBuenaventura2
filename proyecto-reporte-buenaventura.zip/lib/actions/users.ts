"use server"

import { createClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function getUsers() {
  const supabase = await createClient()

  const { data, error } = await supabase.from("users").select("*").order("created_at", { ascending: false })

  if (error) {
    return { error: error.message }
  }

  return { data }
}

export async function updateUserRole(userId: string, role: "admin" | "ciudadano") {
  const supabase = await createClient()

  const { data, error } = await supabase.from("users").update({ role }).eq("id", userId).select().single()

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { data }
}

export async function deleteUser(userId: string) {
  const supabase = await createClient()

  // Check if user has reports
  const { data: reports } = await supabase.from("reports").select("id").eq("user_id", userId).limit(1)

  if (reports && reports.length > 0) {
    return { error: "No se puede eliminar un usuario con reportes" }
  }

  const { error } = await supabase.from("users").delete().eq("id", userId)

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/")
  return { success: true }
}
